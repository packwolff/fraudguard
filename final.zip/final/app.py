import streamlit as st
import pandas as pd
import numpy as np
import pickle
import os


# ============================================================
# PAGE CONFIG
# ============================================================

st.set_page_config(
    page_title="FraudGuard AI",
    page_icon="🛡️",
    layout="wide"
)

st.title("🛡️ FraudGuard AI")
st.subheader("AI-Powered Transaction Risk Detection")


# ============================================================
# LOAD MODEL + PREPROCESSOR
# ============================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_PATH = os.path.join(BASE_DIR, "fraud_model.pkl")
PREPROCESSOR_PATH = os.path.join(BASE_DIR, "preprocessor.pkl")


try:
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)

    with open(PREPROCESSOR_PATH, "rb") as f:
        preprocessor = pickle.load(f)

except Exception as e:
    st.error("❌ Could not load the AI model.")
    st.error(str(e))
    st.stop()


# ============================================================
# DASHBOARD
# ============================================================

st.header("📊 Fraud Detection Dashboard")

col1, col2, col3, col4 = st.columns(4)

col1.metric("Total Transactions", "10,000")
col2.metric("Fraud Detected", "82")
col3.metric("High Risk", "143")
col4.metric("Anomalies", "217")

st.divider()


# ============================================================
# TRANSACTION INPUT
# ============================================================

st.header("🔍 Analyze Transaction")

col1, col2, col3 = st.columns(3)

with col1:
    step = st.number_input(
        "Transaction Step",
        min_value=1,
        value=304
    )

with col2:
    transaction_type = st.selectbox(
        "Transaction Type",
        [
            "TRANSFER",
            "CASH_OUT",
            "PAYMENT",
            "DEPOSIT"
        ]
    )

with col3:
    amount = st.number_input(
        "Transaction Amount (₹)",
        min_value=0.0,
        value=85000.0,
        step=100.0
    )


col1, col2, col3, col4 = st.columns(4)

with col1:
    oldbalance_org = st.number_input(
        "Origin Balance Before",
        min_value=0.0,
        value=85000.0,
        step=100.0
    )

with col2:
    newbalance_orig = st.number_input(
        "Origin Balance After",
        min_value=0.0,
        value=0.0,
        step=100.0
    )

with col3:
    oldbalance_dest = st.number_input(
        "Destination Balance Before",
        min_value=0.0,
        value=50000.0,
        step=100.0
    )

with col4:
    newbalance_dest = st.number_input(
        "Destination Balance After",
        min_value=0.0,
        value=135000.0,
        step=100.0
    )


# ============================================================
# ANALYZE BUTTON
# ============================================================

if st.button(
    "🔎 ANALYZE TRANSACTION",
    use_container_width=True
):

    try:

        # ====================================================
        # FEATURE ENGINEERING
        # ====================================================

        # Fraud dataset uses log-transformed transaction amount
        amount_log = np.log1p(amount)

        # Transaction hour is derived from transaction step.
        # Dataset does not directly provide an hour, so we
        # convert the step into a 24-hour representation.
        hour = int(step % 24)

        # Dataset feature indicating whether a transaction
        # was flagged by the original system.
        is_flagged_fraud = 0


        # ====================================================
        # CREATE MODEL INPUT
        # ====================================================

        transaction = pd.DataFrame({
            "step": [step],
            "type": [transaction_type],
            "amount": [amount],
            "oldbalanceOrg": [oldbalance_org],
            "newbalanceOrig": [newbalance_orig],
            "oldbalanceDest": [oldbalance_dest],
            "newbalanceDest": [newbalance_dest],
            "isFlaggedFraud": [is_flagged_fraud],
            "amount_log": [amount_log],
            "hour": [hour]
        })


        # ====================================================
        # PREPROCESS
        # ====================================================

        processed_transaction = preprocessor.transform(transaction)


        # ====================================================
        # MACHINE LEARNING PREDICTION
        # ====================================================

        prediction = int(
            model.predict(processed_transaction)[0]
        )


        # ====================================================
        # FRAUD PROBABILITY
        # ====================================================

        if hasattr(model, "predict_proba"):

            probabilities = model.predict_proba(
                processed_transaction
            )[0]

            # Probability of class 1 = fraud
            if len(probabilities) > 1:
                fraud_probability = float(probabilities[1])
            else:
                fraud_probability = float(probabilities[0])

        else:

            fraud_probability = 1.0 if prediction == 1 else 0.0


        fraud_percentage = fraud_probability * 100


        # ====================================================
        # BEHAVIORAL ANOMALY DETECTION
        # ====================================================

        anomaly_score = 0
        reasons = []


        # ----------------------------------------------------
        # 1. VERY LARGE TRANSACTION
        # ----------------------------------------------------

        if amount >= 100000:

            anomaly_score += 25

            reasons.append(
                "🔴 Very large transaction amount detected."
            )

        elif amount >= 50000:

            anomaly_score += 15

            reasons.append(
                "🟠 Large transaction amount detected."
            )


        # ----------------------------------------------------
        # 2. ORIGIN ACCOUNT DEPLETION
        # ----------------------------------------------------

        if oldbalance_org > 0:

            depletion_ratio = (
                oldbalance_org - newbalance_orig
            ) / oldbalance_org

            if depletion_ratio >= 0.90:

                anomaly_score += 25

                reasons.append(
                    "🔴 Origin account is almost completely depleted."
                )

            elif depletion_ratio >= 0.50:

                anomaly_score += 15

                reasons.append(
                    "🟠 Large portion of origin balance is transferred."
                )


        # ----------------------------------------------------
        # 3. BALANCE CONSISTENCY
        # ----------------------------------------------------

        expected_origin_balance = (
            oldbalance_org - amount
        )

        if (
            transaction_type in ["TRANSFER", "CASH_OUT"]
            and oldbalance_org > 0
        ):

            difference = abs(
                newbalance_orig - expected_origin_balance
            )

            if difference > max(100, amount * 0.05):

                anomaly_score += 15

                reasons.append(
                    "🟠 Unusual origin balance change detected."
                )


        # ----------------------------------------------------
        # 4. UNUSUAL TIME
        # ----------------------------------------------------

        if hour >= 0 and hour <= 5:

            anomaly_score += 15

            reasons.append(
                "🟠 Transaction occurred during unusual hours."
            )


        # ----------------------------------------------------
        # 5. TRANSFER / CASH OUT
        # ----------------------------------------------------

        if transaction_type in ["TRANSFER", "CASH_OUT"]:

            anomaly_score += 5

            reasons.append(
                "🟡 High-risk transaction type."
            )


        # ----------------------------------------------------
        # LIMIT ANOMALY SCORE
        # ----------------------------------------------------

        anomaly_score = min(anomaly_score, 100)


        # ====================================================
        # HYBRID RISK SCORE
        # ====================================================

        risk_score = (
            fraud_percentage * 0.50
            + anomaly_score * 0.50
        )

        risk_score = min(risk_score, 100)


        # ====================================================
        # FINAL RISK LEVEL
        # ====================================================

        if prediction == 1 or risk_score >= 60:

            risk_level = "HIGH"

        elif risk_score >= 30:

            risk_level = "MEDIUM"

        else:

            risk_level = "LOW"


        # ====================================================
        # FINAL DECISION
        # ====================================================

        if prediction == 1 or risk_score >= 60:

            final_decision = "SUSPICIOUS / POTENTIAL FRAUD"

        else:

            final_decision = "LEGITIMATE"


        # ====================================================
        # DISPLAY RESULTS
        # ====================================================

        st.divider()

        st.header("🚨 Analysis Result")


        # ----------------------------------------------------
        # METRICS
        # ----------------------------------------------------

        col1, col2, col3, col4 = st.columns(4)

        col1.metric(
            "Fraud Probability",
            f"{fraud_percentage:.1f}%"
        )

        col2.metric(
            "Anomaly Score",
            f"{anomaly_score:.1f}%"
        )

        col3.metric(
            "Risk Score",
            f"{risk_score:.1f}%"
        )

        col4.metric(
            "Risk Level",
            risk_level
        )


        # ====================================================
        # STATUS
        # ====================================================

        if risk_level == "HIGH":

            st.error(
                "🔴 HIGH RISK — SUSPICIOUS TRANSACTION"
            )

        elif risk_level == "MEDIUM":

            st.warning(
                "🟠 MEDIUM RISK — REVIEW RECOMMENDED"
            )

        else:

            st.success(
                "🟢 LOW RISK — TRANSACTION APPEARS LEGITIMATE"
            )


        # ====================================================
        # MODEL DECISION
        # ====================================================

        st.subheader("🤖 AI Prediction")

        if prediction == 1:

            st.error(
                "🚨 Machine Learning Model: FRAUD"
            )

        else:

            st.success(
                "✅ Machine Learning Model: LEGITIMATE"
            )


        # ====================================================
        # WHY?
        # ====================================================

        st.subheader("Why?")


        if reasons:

            # Remove duplicate reasons
            unique_reasons = list(dict.fromkeys(reasons))

            for reason in unique_reasons:

                st.write(reason)

        else:

            st.write(
                "🟢 No significant behavioral fraud indicators detected."
            )


        # ====================================================
        # RECOMMENDATION
        # ====================================================

        st.subheader("Recommendation")


        if risk_level == "HIGH":

            st.error(
                "🚨 MANUAL REVIEW REQUIRED"
            )

        elif risk_level == "MEDIUM":

            st.warning(
                "⚠️ ADDITIONAL VERIFICATION RECOMMENDED"
            )

        else:

            st.success(
                "✅ TRANSACTION CAN PROCEED"
            )


        # ====================================================
        # TRANSACTION DETAILS
        # ====================================================

        with st.expander("📋 Transaction Details"):

            details = pd.DataFrame({
                "Feature": [
                    "Transaction Step",
                    "Transaction Type",
                    "Amount",
                    "Origin Balance Before",
                    "Origin Balance After",
                    "Destination Balance Before",
                    "Destination Balance After",
                    "Transaction Hour"
                ],
                "Value": [
                    step,
                    transaction_type,
                    f"₹{amount:,.2f}",
                    f"₹{oldbalance_org:,.2f}",
                    f"₹{newbalance_orig:,.2f}",
                    f"₹{oldbalance_dest:,.2f}",
                    f"₹{newbalance_dest:,.2f}",
                    hour
                ]
            })

            st.table(details)


    # ========================================================
    # ERROR HANDLING
    # ========================================================

    except Exception as e:

        st.error("❌ Prediction failed.")

        st.write("Error:")

        st.code(str(e))

        st.info(
            "The model and preprocessor may have been trained "
            "with different feature names or preprocessing settings."
        )